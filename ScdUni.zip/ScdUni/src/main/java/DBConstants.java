
public class DBConstants {
	public final String Driver="com.mysql.cj.jdbc.Driver";
	public final String connectionUrl="jdbc:mysql://localhost:3306/users";
	

}
